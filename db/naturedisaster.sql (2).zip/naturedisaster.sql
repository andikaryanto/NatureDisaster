-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 24, 2018 at 11:23 AM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `naturedisaster`
--

-- --------------------------------------------------------

--
-- Table structure for table `g_enum`
--

DROP TABLE IF EXISTS `g_enum`;
CREATE TABLE `g_enum` (
  `Id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `g_enum`
--

INSERT INTO `g_enum` (`Id`, `Name`) VALUES
(1, 'Gender'),
(2, 'Religion'),
(3, 'Education'),
(4, 'Marriage Status'),
(5, 'Family Status'),
(6, 'Citizenship');

-- --------------------------------------------------------

--
-- Table structure for table `g_enumdetail`
--

DROP TABLE IF EXISTS `g_enumdetail`;
CREATE TABLE `g_enumdetail` (
  `Id` int(11) NOT NULL,
  `EnumId` int(11) NOT NULL,
  `Value` int(11) NOT NULL,
  `EnumName` varchar(100) NOT NULL,
  `Ordering` int(11) NOT NULL,
  `Resource` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `g_enumdetail`
--

INSERT INTO `g_enumdetail` (`Id`, `EnumId`, `Value`, `EnumName`, `Ordering`, `Resource`) VALUES
(1, 1, 1, 'Male', 1, 'res_male'),
(2, 1, 2, 'Female', 2, 'res_female'),
(3, 2, 1, 'Islam', 1, NULL),
(4, 2, 2, 'Kristen', 2, NULL),
(5, 2, 3, 'Katholik', 3, NULL),
(6, 2, 4, 'Hindu', 4, NULL),
(7, 2, 5, 'Budha', 5, NULL),
(8, 2, 6, 'Other', 6, NULL),
(9, 3, 1, 'SD', 1, NULL),
(10, 3, 2, 'SMP', 2, NULL),
(11, 3, 3, 'SMA/SMK Sederajat', 3, NULL),
(12, 3, 4, 'D3', 4, NULL),
(13, 3, 5, 'S1', 5, NULL),
(14, 3, 6, 'S2', 6, NULL),
(15, 3, 7, 'S3', 7, NULL),
(16, 4, 1, 'Married', 1, 'res_married'),
(17, 4, 2, 'Divorced', 2, 'res_divorced'),
(18, 5, 1, 'Father', 1, 'res_father'),
(19, 5, 2, 'Mother', 2, 'res_mother'),
(20, 5, 3, 'Child', 3, 'res_child'),
(21, 4, 3, 'Single', 3, 'res_single'),
(22, 6, 1, 'WNI', 1, NULL),
(23, 6, 1, 'WNA', 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `g_form`
--

DROP TABLE IF EXISTS `g_form`;
CREATE TABLE `g_form` (
  `Id` int(11) NOT NULL,
  `FormName` varchar(50) NOT NULL,
  `AliasName` varchar(50) NOT NULL,
  `LocalName` varchar(100) DEFAULT NULL,
  `ClassName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `g_form`
--

INSERT INTO `g_form` (`Id`, `FormName`, `AliasName`, `LocalName`, `ClassName`) VALUES
(1, 'm_disaster', 'master disaster', 'master bencana', 'master'),
(2, 'm_user', 'master user', 'master pengguna', 'master'),
(3, 'g_groupuser', 'master group user', 'master group pengguna', 'master'),
(4, 'm_province', 'master province', 'master provinsi', 'master'),
(5, 'm_city', 'master city', 'master kabupaten', 'master'),
(6, 'm_village', 'master village', 'master kelurahan', ''),
(7, 'm_subcity', 'master sub city', 'master kecamatan', ''),
(8, 'm_familycard', 'master family card', 'master kartu keluarga', 'master'),
(9, 'm_animal', 'master animal', 'master hewan', 'master');

-- --------------------------------------------------------

--
-- Table structure for table `g_groupuser`
--

DROP TABLE IF EXISTS `g_groupuser`;
CREATE TABLE `g_groupuser` (
  `Id` int(11) NOT NULL,
  `GroupName` varchar(100) DEFAULT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `IOn` datetime DEFAULT NULL,
  `IBy` varchar(50) DEFAULT NULL,
  `UOn` datetime DEFAULT NULL,
  `UBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `g_groupuser`
--

INSERT INTO `g_groupuser` (`Id`, `GroupName`, `Description`, `IOn`, `IBy`, `UOn`, `UBy`) VALUES
(1, 'Admin', 'Pokok e', NULL, NULL, '2018-07-26 17:15:25', 'superadmin'),
(4, 'Back', 'Back', NULL, NULL, NULL, NULL),
(5, 'wkwkwk', 'wkwkwk', '2018-07-25 09:29:01', 'superadmin', NULL, NULL),
(8, 'master', 'master', '2018-07-26 10:00:42', 'superadmin', '2018-07-26 17:16:19', 'superadmin'),
(16, 'New', 'New', '2018-07-26 17:49:59', 'superadmin', NULL, NULL),
(17, 'Test', 'Test', '2018-07-27 04:51:02', 'superadmin', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `g_language`
--

DROP TABLE IF EXISTS `g_language`;
CREATE TABLE `g_language` (
  `Id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `FlagURL` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `g_language`
--

INSERT INTO `g_language` (`Id`, `Name`, `FlagURL`) VALUES
(1, 'indonesia', 'a'),
(2, 'english', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `m_accessrole`
--

DROP TABLE IF EXISTS `m_accessrole`;
CREATE TABLE `m_accessrole` (
  `Id` int(11) NOT NULL,
  `FormId` varchar(100) DEFAULT NULL,
  `GroupId` int(11) NOT NULL,
  `Read` tinyint(1) NOT NULL,
  `Write` tinyint(1) NOT NULL,
  `Delete` tinyint(1) NOT NULL,
  `Print` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_accessrole`
--

INSERT INTO `m_accessrole` (`Id`, `FormId`, `GroupId`, `Read`, `Write`, `Delete`, `Print`) VALUES
(1, '1', 1, 1, 0, 0, 0),
(2, '1', 4, 1, 0, 0, 0),
(4, '1', 5, 1, 1, 1, 1),
(5, '2', 1, 1, 0, 0, 0),
(6, '3', 1, 1, 0, 0, 0),
(7, '1', 8, 1, 1, 1, 1),
(8, '2', 8, 1, 1, 1, 1),
(9, '3', 8, 0, 0, 0, 0),
(10, '4', 1, 1, 0, 0, 0),
(11, '5', 1, 1, 0, 0, 0),
(12, '6', 1, 0, 0, 0, 0),
(13, '7', 1, 0, 0, 0, 0),
(14, '8', 1, 0, 0, 0, 0),
(15, '9', 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `m_animal`
--

DROP TABLE IF EXISTS `m_animal`;
CREATE TABLE `m_animal` (
  `Id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Description` varchar(300) DEFAULT NULL,
  `IOn` datetime DEFAULT NULL,
  `IBy` varchar(50) DEFAULT NULL,
  `UOn` datetime DEFAULT NULL,
  `UBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_animal`
--

INSERT INTO `m_animal` (`Id`, `Name`, `Description`, `IOn`, `IBy`, `UOn`, `UBy`) VALUES
(1, 'Anjeng', 'Anjeng', '2018-08-02 06:27:21', 'superadmin', '2018-08-02 06:27:25', 'superadmin'),
(2, 'Sapi', 'Sapi', '2018-08-02 06:27:33', 'superadmin', NULL, NULL),
(3, 'Wedhus', 'Wedhus', '2018-08-02 06:27:41', 'superadmin', NULL, NULL),
(4, 'Kucing', 'Kucing', '2018-08-02 08:28:02', 'superadmin', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `m_city`
--

DROP TABLE IF EXISTS `m_city`;
CREATE TABLE `m_city` (
  `Id` int(11) NOT NULL,
  `ProvinceId` int(11) DEFAULT NULL,
  `Name` varchar(50) NOT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `IOn` datetime DEFAULT NULL,
  `IBy` varchar(50) DEFAULT NULL,
  `UOn` datetime DEFAULT NULL,
  `UBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_city`
--

INSERT INTO `m_city` (`Id`, `ProvinceId`, `Name`, `Description`, `IOn`, `IBy`, `UOn`, `UBy`) VALUES
(1, 2, 'Klaten', 'Klaten', '2018-07-27 08:46:06', 'superadmin', '2018-07-29 05:43:29', 'superadmin'),
(2, 1, 'Bantul', 'Bantul', '2018-07-27 08:54:41', 'superadmin', NULL, NULL),
(3, 1, 'Sleman', 'Sleman', '2018-07-27 09:19:34', 'superadmin', NULL, NULL),
(4, 1, 'Kulon Progo', 'Kulon Progo', '2018-07-27 09:26:58', 'superadmin', '2018-07-27 09:27:38', 'superadmin');

-- --------------------------------------------------------

--
-- Table structure for table `m_disaster`
--

DROP TABLE IF EXISTS `m_disaster`;
CREATE TABLE `m_disaster` (
  `Id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Description` varchar(300) NOT NULL,
  `IOn` datetime DEFAULT NULL,
  `IBy` varchar(50) DEFAULT NULL,
  `UOn` datetime DEFAULT NULL,
  `UBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_disaster`
--

INSERT INTO `m_disaster` (`Id`, `Name`, `Description`, `IOn`, `IBy`, `UOn`, `UBy`) VALUES
(1, 'Kebakaran', 'Kebakaran', '2018-07-19 00:00:00', 'andik', NULL, NULL),
(2, 'Pohon Tumbang', 'Pohon Tumbang', NULL, NULL, NULL, NULL),
(3, 'Angin', 'Angin', '2018-07-20 11:37:40', 'andik', NULL, NULL),
(4, 'Tanah Longsor', 'Tanah Longsor', '2018-07-20 11:38:41', 'andik', NULL, NULL),
(12, 'AS', 'AS', '2018-07-23 10:19:59', 'andik', NULL, NULL),
(13, 'hehe', 'hehe', '2018-07-23 10:20:10', 'andik', '2018-07-26 11:57:07', 'superadmin'),
(14, 'Test', 'Test', '2018-07-24 06:01:40', 'superadmin', '2018-07-26 16:41:12', 'superadmin'),
(15, 'Roboh', 'Roboh', '2018-07-26 17:49:29', 'Eir', '2018-07-26 17:49:33', 'Eir'),
(16, 'Kosong', 'Kosong', '2018-07-27 05:31:04', 'superadmin', NULL, NULL),
(17, 'api', 'api desc', NULL, NULL, NULL, NULL),
(18, 'wkwkwkwkassw', 'api desc', NULL, NULL, NULL, NULL),
(19, 'hehehehehehehe', 'api desc', '2018-07-30 05:16:39', 'android', NULL, NULL),
(20, 'andik dooonk', 'api desc', '2018-07-30 05:20:14', 'android', NULL, NULL),
(21, 'andik testt', 'api desc', '2018-07-30 06:46:08', 'android', NULL, NULL),
(24, 'post', 'post', '2018-07-31 05:46:16', 'android', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `m_familycard`
--

DROP TABLE IF EXISTS `m_familycard`;
CREATE TABLE `m_familycard` (
  `Id` int(11) NOT NULL,
  `CardNo` varchar(50) NOT NULL,
  `HeadFamilyName` varchar(100) NOT NULL,
  `VillageId` int(11) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `RT` varchar(10) DEFAULT NULL,
  `RW` varchar(10) DEFAULT NULL,
  `PostCode` varchar(20) DEFAULT NULL,
  `IOn` datetime DEFAULT NULL,
  `IBy` varchar(50) DEFAULT NULL,
  `UOn` datetime DEFAULT NULL,
  `UBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_familycard`
--

INSERT INTO `m_familycard` (`Id`, `CardNo`, `HeadFamilyName`, `VillageId`, `Address`, `RT`, `RW`, `PostCode`, `IOn`, `IBy`, `UOn`, `UBy`) VALUES
(1, '3310923421203234', 'Andik', 6, 'Jl. Nglorok Tegalsari ', '3', '4', '47466', '2018-07-30 09:37:53', 'superadmin', '2018-08-23 10:36:41', 'superadmin'),
(2, '331024342341415', 'Mueheheh', 5, 'Senden', '4', '44', '2354345', '2018-07-30 09:41:16', 'superadmin', '2018-07-30 10:06:56', 'superadmin'),
(4, 'sdasd', 'sdasd', 6, 'sdasd', 'asda', 'asda', 'asda', '2018-07-30 10:21:15', 'superadmin', '2018-08-01 09:34:54', 'superadmin');

-- --------------------------------------------------------

--
-- Table structure for table `m_familycardanimal`
--

DROP TABLE IF EXISTS `m_familycardanimal`;
CREATE TABLE `m_familycardanimal` (
  `Id` int(11) NOT NULL,
  `AnimalId` int(11) NOT NULL,
  `FamilyCardId` int(11) NOT NULL,
  `Qty` int(11) NOT NULL,
  `IOn` datetime DEFAULT NULL,
  `IBy` varchar(50) DEFAULT NULL,
  `UOn` datetime DEFAULT NULL,
  `UBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_familycardanimal`
--

INSERT INTO `m_familycardanimal` (`Id`, `AnimalId`, `FamilyCardId`, `Qty`, `IOn`, `IBy`, `UOn`, `UBy`) VALUES
(1, 1, 1, 1, NULL, NULL, '2018-08-24 06:26:06', 'superadmin'),
(2, 2, 1, 2, '2018-08-01 09:23:09', 'superadmin', '2018-08-24 06:26:42', 'superadmin'),
(3, 3, 1, 5, '2018-08-24 06:30:58', 'superadmin', NULL, NULL),
(4, 4, 1, 1, '2018-08-24 06:31:06', 'superadmin', NULL, NULL),
(5, 3, 1, 5, '2018-08-24 06:31:12', 'superadmin', NULL, NULL),
(6, 4, 1, 2, '2018-08-24 06:31:25', 'superadmin', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `m_familycarddetail`
--

DROP TABLE IF EXISTS `m_familycarddetail`;
CREATE TABLE `m_familycarddetail` (
  `Id` int(11) NOT NULL,
  `FamilyCardId` int(11) NOT NULL,
  `Name` varchar(300) NOT NULL,
  `NIK` varchar(50) DEFAULT NULL,
  `Gender` smallint(1) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `PlaceOfBirth` varchar(100) DEFAULT NULL,
  `Religion` int(11) DEFAULT NULL,
  `LastEducation` smallint(1) DEFAULT NULL,
  `KindOfJob` varchar(100) DEFAULT NULL,
  `MarriageStatus` smallint(1) DEFAULT NULL,
  `FamilyStatus` smallint(1) DEFAULT NULL,
  `Citizenship` smallint(1) DEFAULT NULL,
  `PasportNo` varchar(50) DEFAULT NULL,
  `KitaNo` varchar(50) DEFAULT NULL,
  `FathersName` varchar(100) DEFAULT NULL,
  `MothersName` varchar(100) DEFAULT NULL,
  `IsHeadFamily` smallint(6) DEFAULT NULL,
  `IOn` datetime DEFAULT NULL,
  `IBy` varchar(50) DEFAULT NULL,
  `UOn` datetime DEFAULT NULL,
  `UBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_familycarddetail`
--

INSERT INTO `m_familycarddetail` (`Id`, `FamilyCardId`, `Name`, `NIK`, `Gender`, `DateOfBirth`, `PlaceOfBirth`, `Religion`, `LastEducation`, `KindOfJob`, `MarriageStatus`, `FamilyStatus`, `Citizenship`, `PasportNo`, `KitaNo`, `FathersName`, `MothersName`, `IsHeadFamily`, `IOn`, `IBy`, `UOn`, `UBy`) VALUES
(2, 1, 'Andik', '3310220602910001', 1, '1991-02-06', 'Klaten', 1, 5, 'Dont Ask', 1, 1, 1, '', '', 'Witanto', 'Sutniem', 1, '2018-08-01 09:23:09', 'superadmin', '2018-08-01 11:35:20', 'superadmin'),
(3, 1, 'Adel', '234535234', 2, '1991-04-26', 'Grobogan', 1, 3, 'IRT', 1, 2, 1, '', '', 'Suwardi', 'Bati', 0, '2018-08-01 11:30:50', 'superadmin', '2018-08-02 03:39:55', 'superadmin'),
(4, 1, 'Ainaya', '', 2, '2017-02-21', 'Grobogan', 1, 1, '', 1, 3, 1, '', '', 'Andik', 'Adel', 0, '2018-08-01 11:37:07', 'superadmin', NULL, NULL),
(5, 1, 'asd', '', 1, '2018-01-08', '', 1, 1, '', 1, 1, 1, '', '', '', '', 0, '2018-08-01 11:37:17', 'superadmin', NULL, NULL),
(7, 1, 'dfsdf', '', 1, '2018-01-08', '', 1, 1, '', 1, 1, 1, '', '', '', '', 0, '2018-08-01 11:37:24', 'superadmin', NULL, NULL),
(8, 1, 'fff', '', 1, '2018-01-08', '', 1, 1, '', 1, 1, 1, '', '', '', '', 0, '2018-08-01 12:03:16', 'superadmin', NULL, NULL),
(9, 1, 'ggg', '', 1, '2018-01-08', '', 1, 1, '', 1, 1, 1, '', '', '', '', 0, '2018-08-01 12:03:21', 'superadmin', NULL, NULL),
(10, 1, 'hhhh', '', 1, '2018-01-08', '', 1, 1, '', 1, 1, 1, '', '', '', '', 0, '2018-08-01 12:03:23', 'superadmin', NULL, NULL),
(11, 1, 'ssss', '', 1, '2018-01-08', '', 1, 1, '', 1, 1, 1, '', '', '', '', 0, '2018-08-01 12:03:26', 'superadmin', NULL, NULL),
(12, 1, 'test', '2345234554', 2, '1970-01-01', 'Klaten', 1, 4, '', 3, 3, 1, '', '', 'Andik', 'Adel', 0, '2018-08-23 10:36:29', 'superadmin', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `m_province`
--

DROP TABLE IF EXISTS `m_province`;
CREATE TABLE `m_province` (
  `Id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Description` varchar(300) DEFAULT NULL,
  `IOn` datetime DEFAULT NULL,
  `IBy` varchar(50) DEFAULT NULL,
  `UOn` datetime DEFAULT NULL,
  `UBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_province`
--

INSERT INTO `m_province` (`Id`, `Name`, `Description`, `IOn`, `IBy`, `UOn`, `UBy`) VALUES
(1, 'Yogyakarta', 'Yogyakarta', '2018-07-27 05:50:32', 'superadmin', '2018-07-29 05:43:13', 'superadmin'),
(2, 'Jawa Tengah', 'Jawa Tengah', '2018-07-27 05:50:52', 'superadmin', NULL, NULL),
(3, 'Jawa Timur', 'Jawa Timur', '2018-07-27 05:51:02', 'superadmin', NULL, NULL),
(4, 'Jawa Barat', 'Jawa Barat', '2018-07-27 05:51:12', 'superadmin', NULL, NULL),
(5, 'DKI Jakarta', 'DKI Jakarta', '2018-07-27 05:53:10', 'superadmin', NULL, NULL),
(6, 'Banten', 'Banten', '2018-07-27 08:08:12', 'superadmin', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `m_subcity`
--

DROP TABLE IF EXISTS `m_subcity`;
CREATE TABLE `m_subcity` (
  `Id` int(11) NOT NULL,
  `CityId` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Description` varchar(300) DEFAULT NULL,
  `IOn` datetime DEFAULT NULL,
  `IBy` varchar(50) DEFAULT NULL,
  `UON` datetime DEFAULT NULL,
  `UBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_subcity`
--

INSERT INTO `m_subcity` (`Id`, `CityId`, `Name`, `Description`, `IOn`, `IBy`, `UON`, `UBy`) VALUES
(1, 1, 'Ngawen', 'Ngawen', '2018-07-27 11:23:52', 'superadmin', '2018-07-29 05:43:35', 'superadmin'),
(2, 1, 'Jatinom', 'Jatinom', '2018-07-27 11:26:47', 'superadmin', '2018-07-29 05:43:39', 'superadmin');

-- --------------------------------------------------------

--
-- Table structure for table `m_user`
--

DROP TABLE IF EXISTS `m_user`;
CREATE TABLE `m_user` (
  `Id` int(11) NOT NULL,
  `GroupId` int(11) DEFAULT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `IOn` datetime DEFAULT NULL,
  `IBy` varchar(50) DEFAULT NULL,
  `UOn` datetime DEFAULT NULL,
  `UBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_user`
--

INSERT INTO `m_user` (`Id`, `GroupId`, `UserName`, `Password`, `IOn`, `IBy`, `UOn`, `UBy`) VALUES
(1, 1, 'andik', 'andik', '2018-07-20 00:00:00', 'hehehe', '2018-07-26 16:57:50', 'superadmin'),
(2, 8, 'test', 'test', '2018-07-20 08:28:40', 'andik', '2018-07-26 17:16:05', 'superadmin'),
(3, 1, 'hehe', '', '2018-07-20 08:30:22', 'andik', '2018-07-26 11:35:33', 'superadmin'),
(4, NULL, 'superadmin', 'p@ssw0rd', NULL, NULL, NULL, NULL),
(5, 8, 'Eir', 'Eir', '2018-07-26 11:08:41', 'superadmin', '2018-07-27 05:34:23', 'superadmin');

-- --------------------------------------------------------

--
-- Table structure for table `m_usergroupuser`
--

DROP TABLE IF EXISTS `m_usergroupuser`;
CREATE TABLE `m_usergroupuser` (
  `Id` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `GrupId` int(11) NOT NULL,
  `IOn` datetime NOT NULL,
  `IBy` varchar(50) NOT NULL,
  `UOn` datetime NOT NULL,
  `UBy` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `m_village`
--

DROP TABLE IF EXISTS `m_village`;
CREATE TABLE `m_village` (
  `Id` int(11) NOT NULL,
  `SubcityId` int(11) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Description` varchar(300) NOT NULL,
  `IOn` datetime DEFAULT NULL,
  `IBy` varchar(50) DEFAULT NULL,
  `UOn` datetime DEFAULT NULL,
  `UBy` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_village`
--

INSERT INTO `m_village` (`Id`, `SubcityId`, `Name`, `Description`, `IOn`, `IBy`, `UOn`, `UBy`) VALUES
(1, 1, 'Manjung', 'Manjung', '2018-07-27 10:30:39', 'superadmin', NULL, NULL),
(2, 1, 'Jebugan', 'Jebugan', '2018-07-27 10:31:13', 'superadmin', NULL, NULL),
(5, 2, 'Ngupit', 'Ngupit', '2018-07-27 11:45:28', 'superadmin', NULL, NULL),
(6, 1, 'WKWKWK', 'hohoho', '2018-07-27 11:50:42', 'superadmin', NULL, NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_m_accessrole`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `view_m_accessrole`;
CREATE TABLE `view_m_accessrole` (
`GroupId` int(11)
,`FormId` int(11)
,`FormName` varchar(50)
,`AliasName` varchar(50)
,`LocalName` varchar(100)
,`Readd` int(4)
,`Writee` int(4)
,`Deletee` int(4)
,`Printt` int(4)
);

-- --------------------------------------------------------

--
-- Structure for view `view_m_accessrole`
--
DROP TABLE IF EXISTS `view_m_accessrole`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_m_accessrole`  AS  select `a`.`Id` AS `GroupId`,`b`.`Id` AS `FormId`,`b`.`FormName` AS `FormName`,`b`.`AliasName` AS `AliasName`,`b`.`LocalName` AS `LocalName`,ifnull(`c`.`Read`,0) AS `Readd`,ifnull(`c`.`Write`,0) AS `Writee`,ifnull(`c`.`Delete`,0) AS `Deletee`,ifnull(`c`.`Print`,0) AS `Printt` from ((`g_groupuser` `a` join `g_form` `b`) left join `m_accessrole` `c` on(((`c`.`FormId` = `b`.`Id`) and (`c`.`GroupId` = `a`.`Id`)))) order by `a`.`Id` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `g_enum`
--
ALTER TABLE `g_enum`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `g_enumdetail`
--
ALTER TABLE `g_enumdetail`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `g_form`
--
ALTER TABLE `g_form`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Id` (`Id`);

--
-- Indexes for table `g_groupuser`
--
ALTER TABLE `g_groupuser`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Id` (`Id`) USING BTREE;

--
-- Indexes for table `g_language`
--
ALTER TABLE `g_language`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Id` (`Id`);

--
-- Indexes for table `m_accessrole`
--
ALTER TABLE `m_accessrole`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Id` (`Id`);

--
-- Indexes for table `m_animal`
--
ALTER TABLE `m_animal`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `m_city`
--
ALTER TABLE `m_city`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `m_disaster`
--
ALTER TABLE `m_disaster`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Id` (`Id`);

--
-- Indexes for table `m_familycard`
--
ALTER TABLE `m_familycard`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `m_familycardanimal`
--
ALTER TABLE `m_familycardanimal`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `m_familycarddetail`
--
ALTER TABLE `m_familycarddetail`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `m_province`
--
ALTER TABLE `m_province`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `m_subcity`
--
ALTER TABLE `m_subcity`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `m_user`
--
ALTER TABLE `m_user`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Id` (`Id`);

--
-- Indexes for table `m_usergroupuser`
--
ALTER TABLE `m_usergroupuser`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Id` (`Id`);

--
-- Indexes for table `m_village`
--
ALTER TABLE `m_village`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `g_enum`
--
ALTER TABLE `g_enum`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `g_enumdetail`
--
ALTER TABLE `g_enumdetail`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `g_form`
--
ALTER TABLE `g_form`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `g_groupuser`
--
ALTER TABLE `g_groupuser`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `g_language`
--
ALTER TABLE `g_language`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `m_accessrole`
--
ALTER TABLE `m_accessrole`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `m_animal`
--
ALTER TABLE `m_animal`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `m_city`
--
ALTER TABLE `m_city`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `m_disaster`
--
ALTER TABLE `m_disaster`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `m_familycard`
--
ALTER TABLE `m_familycard`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `m_familycardanimal`
--
ALTER TABLE `m_familycardanimal`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `m_familycarddetail`
--
ALTER TABLE `m_familycarddetail`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `m_province`
--
ALTER TABLE `m_province`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `m_subcity`
--
ALTER TABLE `m_subcity`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `m_user`
--
ALTER TABLE `m_user`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `m_usergroupuser`
--
ALTER TABLE `m_usergroupuser`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `m_village`
--
ALTER TABLE `m_village`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
